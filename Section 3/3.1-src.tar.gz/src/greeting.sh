#!/bin/bash

echo $GREETING, $NAME!
